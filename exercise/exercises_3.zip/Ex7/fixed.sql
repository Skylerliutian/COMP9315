create table R (
	x integer,
	c char(10),
	y float
	d varchar(10), // ruins fixed-size
	primary key(x)
);
