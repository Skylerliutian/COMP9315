typedef unsigned int uint32;

uint32 hash_any(unsigned char *, int);

char *showBits(uint32, char *);

uint32 bits(int d, uint32 val);
